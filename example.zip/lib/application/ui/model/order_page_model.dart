class OrderList {
  static const List<String> costOfOrders = [
    "৳700",
    "৳452",
    "৳281",
  ];
  static const List<String> deliverid = [
    "Delivered",
    "Cancelled",
    "Delivered",
  ];
}
