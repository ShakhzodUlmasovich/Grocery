class SnaclsPagetInfo {
  static const List<String> listImages = [
    "assets/images/Rectangl1.png",
    "assets/images/Rectangl2.png",
    "assets/images/coffe3.png",
    "assets/images/Rectangle4.png",
  ];
  static const List<String> listText = [
    "Radhuni Shemai - 200 gm - 4-2-15-VD-SQ",
    "Cheese Puffs Chips - 22\ngm",
    "Nescafe Classic Coffee Jar - 50gm",
    "Akher Chini (Deshi Sugar) – 1kg",
  ];
}
