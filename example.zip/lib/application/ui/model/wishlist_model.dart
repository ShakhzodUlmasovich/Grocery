class WishListInfo {
  static const List<String> listImages = [
    "assets/images/Milk2.png",
    "assets/images/Milk1.png",
  ];
}
