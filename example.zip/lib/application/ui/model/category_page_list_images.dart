class CategoryLisPagetInfo {
  static const List<String> listImages = [
    "assets/images/image1.png",
    "assets/images/image2.png",
    "assets/images/image3.png",
    "assets/images/image4.png",
    "assets/images/image5.png",
    "assets/images/image6.png"
  ];
  static const List<String> listText = [
    "Fruits & Vegetables",
    "Breakfast",
    "Beverages",
    "Meat & Fish",
    "Snacks",
    "Dairy",
  ];
}
