class CategoryListInfo {
  static const List<String> listImages = [
    "assets/images/yqTmbqbktA-removebg-preview 1.png",
    "assets/images/kFMOBju1RGr39iATJh26BvFa-removebg-preview (2) 1.png",
    "assets/images/m31sgME_-removebg-preview 1.png",
    "assets/images/YDXyCNvw3gyRwLM1apNSQVMs1y56lN0s_-removebg-preview 1.png",
    "assets/images/at2XY9OnJ6-removebg-preview 1.png",
    "assets/images/UMr+m-removebg-preview 1.png",
  ];
  static const List<String> listText = [
    "Fruits & Vegetables",
    "Breakfast",
    "Beverages",
    "Meat & Fish",
    "Snacks",
    "Dairy",
  ];
}
