import 'package:flutter/material.dart';

TextStyle get hintStyle => const  TextStyle(fontSize: 18.0, color: Colors.black,); 