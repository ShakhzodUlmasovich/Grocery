import '../constants/import_packages.dart';

class RegisterPage extends StatelessWidget {
  const RegisterPage({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          "Register",
          style: TextStyle(fontSize: 25.0),
        ),
      ),
    );
  }
}